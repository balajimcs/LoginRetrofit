package com.example.loginretrofit.models

data class DefaultResponse(val error: Boolean, val message:String)